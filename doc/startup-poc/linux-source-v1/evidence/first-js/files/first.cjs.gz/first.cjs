const first=process.hrtime.bigint();require('node:fs').writeSync(1,String(first)+'\n');
