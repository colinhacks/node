const first=process.hrtime.bigint();const fs=await import('node:fs');fs.writeSync(1,String(first)+'\n');
